<?php
class save extends model
{
	
}
?>
